from PIL import Image
import os

for dir_name in os.listdir("generated_molfiles/molvec"):
    for i in range(1, 130):
        src = "generated_molfiles/molvec/" + dir_name + "/" + str(i) + ".tif.mol"
        dest = "generated_molfiles/molvec/" + dir_name + "/" + str(i) + ".mol"
        try:
            os.rename(src, dest)
        except:
            pass