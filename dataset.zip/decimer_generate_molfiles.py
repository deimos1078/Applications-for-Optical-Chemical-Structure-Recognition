from DECIMER import predict_SMILES
from rdkit import Chem
import os
import time

path = 'data'
for dir_name in os.listdir(path):
    os.makedirs('generated_molfiles/decimer/' + dir_name, exist_ok = True)
    for i in range(1, 130):
        image_path = 'data/' + dir_name + '/' + str(i) + '.tif'
        SMILES = predict_SMILES(image_path)
        mol = Chem.MolFromSmiles(SMILES)
        if (mol is None):
            mol = Chem.MolFromSmiles('C1NCN1.C1NCN1') #structure indicating failure to parse smiles
        print(str(i) + " -> " + SMILES)
        try:
            molfile = Chem.MolToMolBlock(mol)
        except:
            molfile = Chem.MolToMolBlock(Chem.MolFromSmiles('C1NCN1.C1NCN1'))
        output_file = 'generated_molfiles/decimer/' + dir_name + '/' + str(i) + '.mol'
        with open(output_file, "w") as f:
            f.write(molfile)
